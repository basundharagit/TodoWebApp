

# Create your views here.
from django.shortcuts import redirect, render, HttpResponse
from .models import Todo

# CRUD - Create, Read, Update and Delete

 
# Create your views here.
def index(request):
    if request.method == "POST":
        task_title = request.POST['task_title']
        todo = Todo(title = task_title)
        todo.save()

    tasks = Todo.objects.all()
    context = {'tasks':tasks}
    return render(request,'index.html',context)

def delete(request,id_num):
    
    deleted_task = Todo.objects.get(id = id_num)
    deleted_task.delete()
    return redirect('/')


def update(request,id_num):
    updated_task = Todo.objects.get(id=id_num)
    context = {'updated_task':updated_task}
    if request.method == "POST":
        new_task_title = request.POST['new_task_title']
        updated_task.title = new_task_title
        updated_task.save()
        return redirect('/')
    return render(request,'update.html',context)

