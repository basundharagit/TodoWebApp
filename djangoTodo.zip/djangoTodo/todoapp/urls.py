from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="index"),
    path('delete/<int:id_num>', views.delete, name="delete"),
    path('update/<int:id_num>', views.update, name="update"),
    
    
]